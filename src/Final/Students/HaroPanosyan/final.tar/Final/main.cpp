#include <cstdio>
#include <cstdlib>
#include <cstring>
 
#include <vector>
#include <list>
#include <map>
#include <set>
 
#include <iostream>
using namespace std;
 
#include "macros.h"     // Redundant, already in the <dp>.h files, but may need if you change the directory structure implied below.
 
#include "Problems/strategy.h"
#include "Solutions/strategy.h"
// Seam point - include next design pattern.
 
#include "Problems/adapter.h"
#include "Solutions/adapter.h"

#include "Problems/factoryMethod.h"
#include "Solutions/factoryMethod.h"

#include "Problems/templateMethod.h"
#include "Solutions/templateMethod.h"

#include "Problems/observer.h"
#include "Solutions/observer.h"

#include "Problems/decorator.h"
#include "Solutions/decorator.h"

#include "Problems/chainOfResp.h"
#include "Solutions/chainOfResp.h"

#include "Problems/bridge.h"
#include "Solutions/bridge.h"

#include "Problems/abstractFactory.h"
#include "Solutions/abstractFactory.h"

int main(int argc, char* args[]) {
    if(argc != 2) {
        printf("Usage: ./a.out <dp-number> (1-9)\n");
        exit(-1);
    }
 
    int dp = atoi(args[1]);
 
    switch(dp) {
    case 1:
        strategy::legacy::demo(dp);
        strategy::problem::demo(dp);
        strategy::solution::demo(dp);
        break;
    // Seam point - add next design pattern.
 
    case 2:
        adapter::legacy::demo(dp);
        adapter::problem::demo(dp);
        adapter::solution::demo(dp);
        break;

    case 3:
        factoryMethod::legacy::demo(dp);
        factoryMethod::problem::demo(dp);
        factoryMethod::solution::demo(dp);
        break;

    case 4:
        templateMethod::legacy::demo(dp);
        templateMethod::problem::demo(dp);
        templateMethod::solution::demo(dp);
        break;

    case 5:
        observer::legacy::demo(dp);
        observer::problem::demo(dp);
        observer::solution::demo(dp);
        break;

    case 6:
        decorator::legacy::demo(dp);
        decorator::problem::demo(dp);
        decorator::solution::demo(dp);
        break;

    case 7:
        chainofresp::legacy::demo(dp);
        chainofresp::problem::demo(dp);
        chainofresp::solution::demo(dp);
        break;

    case 8:
        bridge::legacy::demo(dp);
        bridge::problem::demo(dp);
        bridge::solution::demo(dp);
        break;

    case 9:
        abstractfactory::legacy::demo();
        abstractfactory::problem::demo();
        abstractfactory::solution::demo();
        break;

    default:
    	printf("Unknown design pattern number %d.\n", dp);
	    break;
    }
 
    printf("Done.\n");
}
