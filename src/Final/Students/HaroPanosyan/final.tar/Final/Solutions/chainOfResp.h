/*
 * chainOfResp.h
 *
 *  Created on: Sep 26, 2015
 *      Author: aldgoff
 *
 * Varies: If the responders are varying, use the Chain of Responsibility pattern.
 *
 * Desc:
 *
 * Category: whatever
 *
 *  URLs:
 *  	http://en.wikibooks.org/wiki/C%2B%2B_Programming/Code/Design_Patterns#ChainOfReponsibility
 *  	http://www.dofactory.com/net/chain-of-responsibility-design-pattern
 *
 *  	http://sourcemaking.com/design_patterns/chain_of_responsibility
 */

#ifndef SOLUTIONS_CHAINOFRESP_H_
#define SOLUTIONS_CHAINOFRESP_H_

/* Consider how to model decision making in a military chain of command.
 * Simple decisions get made by the junior officers,
 * harder ones by the senior officers.
 * Model the major being killed in action.
 */

namespace chainofresp {

namespace solution {

class Soldier {
	protected :
		Soldier* next;
		int MaxResponsibility;

	public : 
		Soldier(int MR) : MaxResponsibility(MR), next(0) {}
	
		virtual ~Soldier(){}
		
		void setNext(Soldier* s) {
			next = s;
		}
		
		void add(Soldier* s) {
			if (next)
				next->add(s);
			else
				next = s;
		}
		
		virtual void makeDecision(int livesAtRisk) = 0;
};

class Lieutenant : public Soldier {
public:
	Lieutenant(int MR) : Soldier(MR) { cout << "  +Lieutenant\n"; }
	~Lieutenant() {
		DTOR("  ~Lieutenant\n", Homework);
	}
public:
	void makeDecision(int livesAtRisk) {
		if(livesAtRisk < MaxResponsibility)
			cout << "  Lieutenant charges " <<livesAtRisk<<".\n";
		else
			next->makeDecision(livesAtRisk);
	}
};

class Captain : public Soldier {
public:
	Captain(int MR) : Soldier(MR) { cout << "  +Captain\n"; }
	~Captain() {
		DTOR("  ~Captain\n", Homework);
	}
public:
	void makeDecision(int livesAtRisk) {
		if(livesAtRisk < MaxResponsibility)
			cout << "  Captain retreats " << livesAtRisk <<".\n";
		else
			next->makeDecision(livesAtRisk);
	}
};

class Major : public Soldier {
public:
	Major(int MR) : Soldier(MR) { cout << "  +Major\n"; }
	~Major() {
		DTOR("  ~Major\n", Homework);
	}
public:
	void makeDecision(int livesAtRisk) {
		if(livesAtRisk < MaxResponsibility)
			cout << "  Major flanks " << livesAtRisk << ".\n";
		else
			next->makeDecision(livesAtRisk);
	}
};

class Colonel : public Soldier {
public:
	Colonel(int MR) : Soldier(MR) { cout << "  +Colonel\n"; }
	~Colonel() {
		DTOR("  ~Colonel\n", Homework);
	}
public:
	void makeDecision(int livesAtRisk) {
		if(livesAtRisk < MaxResponsibility)
			cout << "  Colonel gathers intel "<<livesAtRisk<<".\n";
		else
			next->makeDecision(livesAtRisk);
	}
};

class General : public Soldier {
public:
	General(int MR) : Soldier(MR) { cout << "  +General\n"; }
	~General() {
		DTOR("  ~General\n", Homework);
	}
public:
	void makeDecision(int livesAtRisk) {
		if(livesAtRisk < MaxResponsibility)
			cout << "  General strategizes " <<livesAtRisk<<".\n";
		else
			next->makeDecision(livesAtRisk);
	}
};

class CommanderInChief : public Soldier {
public:
	CommanderInChief(int MR) : Soldier(MR) { cout << "  +CommanderInChief\n"; }
	~CommanderInChief() {
		DTOR("  ~CommanderInChief\n", Homework);
	}
public:
	void makeDecision(int livesAtRisk) {
		if(livesAtRisk < MaxResponsibility)
			cout << "  Pres negotiates " << livesAtRisk << ".\n";
		else {
			cout << "  Pres connot negotiate for " << livesAtRisk << ".\n";
			throw "OOPS";
		}
	}
};


Soldier* Soldiers[7];

void setup() {
	Soldiers[0]	= new Lieutenant(10);
	Soldiers[1]	= new Captain(20);
	Soldiers[2]	= new Major(100);
	Soldiers[3]	= new Major(200);// Notice Double Major with different rankings
	Soldiers[4]	= new Colonel(5000);
	Soldiers[5]	= new General(100000);
	Soldiers[6]	= new CommanderInChief(350000000);
	// Seam point - insert another officer.
	Soldiers[0]->add(Soldiers[1]);
	Soldiers[0]->add(Soldiers[2]);
	Soldiers[0]->add(Soldiers[3]);
	Soldiers[0]->add(Soldiers[4]);
	Soldiers[0]->add(Soldiers[5]);
	Soldiers[0]->add(Soldiers[6]);
	Soldiers[6]->setNext(Soldiers[0]);
}

void teardown() {
	delete Soldiers[0];
	delete Soldiers[1];
	delete Soldiers[2];
	delete Soldiers[3];
	delete Soldiers[4];
	delete Soldiers[5];
	delete Soldiers[7];
	
	// Seam point - delete another officer.
}

void clientCode(int livesAtRisk) {
	Soldiers[0]->makeDecision(livesAtRisk);
 	// NO MORE Seam point - insert another decision level.
}

void demo(int seqNo) {
	cout << seqNo <<") << chainofresp::homework::legacy::demo() >>\n";
	
	setup();

	int data[] = { 4000000, 4000, 5, 15, 80, 1155, 8144, 400000, 150 };//Notice out of order
	for(size_t i=0; i<COUNT(data); i++) {
		clientCode(data[i]);
	}

	teardown();

	cout << endl;
}

} // solution

} // chainofresp

#endif /* SOLUTIONS_CHAINOFRESP_H_ */
