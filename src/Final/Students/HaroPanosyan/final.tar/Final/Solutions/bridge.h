/*
 * bridge.h
 *
 *  Created on: Oct 21, 2015
 *      Author: aldgoff
 *
 * Varies: If the abstractions and implementations are varying, use the Bridge pattern.
 *
 * Desc: Decouples an abstraction from its implementations so they can vary independently.
 *
 * Category: Structural
 *
 *  URLs:
 *  	http://en.wikibooks.org/wiki/C%2B%2B_Programming/Code/Design_Patterns#Bridge
 *  	http://www.dofactory.com/net/bridge-design-pattern
 *  	http://www.netobjectives.com/resources/books/design-patterns-explained/review-questions#Chapter10
 *  	http://sourcemaking.com/design_patterns/bridge
 */

#ifndef SOLUTIONS_BRIDGE_H_
#define SOLUTIONS_BRIDGE_H_

/* Consider a graphics program that must run on multiple platforms.
 * Each platform provides different drawing primitives for lines & arcs.
 * Basic shapes can be constructed from these primitives, such as
 *   rectangles, circles, etc.
 *
 * Use the bridge pattern to write code that avoids the combinatorial explosion
 * of classes and methods which a procedural approach entails.
 * Show how adding another shape or platform requires only a linear amount of
 * additional code.
 *
 * Rectangle, draw 4 lines (upper left corner: x1,y1, lower right corner: x2,y2).
 *	 draw(x1,y1, x2,y1) draw(x2,y1, x2,y2) draw(x2,y2, x1,y2) draw(x1,y2, x1,y1)
 * Circle, draw 4 arcs (90 degrees, clockwise, center is x,y).
 *	 draw(x,y+r, x+r,y) draw(x+r,y, x,y-r) draw(x,y-r, x-r,y) draw(x-r,y, x,y+r)
 * Triangle, draw 3 lines between 3 vert;ices.
 *   draw(vert1.first,vert1.second, vert2.first,vert2.second)
 *   draw(vert2.first,vert2.second, vert3.first,vert3.second)
 *   draw(vert3.first,vert3.second, vert1.first,vert1.second)
 *
 * In this problem, the Shape hierarchy has already been implemented
 * with Rectangle and Circle for the legacy code.
 * A Triangle and a plotter platform were added for the problem code.
 * Note the quadratic scaling in the source code.
 *
 * Refactor using the Bridge pattern showing how it avoids the quadratic scaling.
 *
 * For extra credit redo using the GoF creational pattern Factory Method
 * to encapsulate the creation of the appropriate derived Shape class.
 */

namespace bridge {

namespace solution {

class DrawImpl { // abstract impl
	public: 
		std::string name;
		DrawImpl(){}
	public: 
		virtual void drawLine(double x1, double y1, double x2, double y2) = 0;
		virtual void drawArc(double x1, double y1, double x2, double y2) = 0;
};

class DrawVector : public DrawImpl {
	public: 
		DrawVector() {name = "vector";}
	public: 
		virtual void drawLine(double x1, double y1, double x2, double y2) {
			cout << "    Draw vector line: ["<<x1<<","<<y1<<"] ["<<x2<<","<<y2<<"]\n";
		}
		virtual void drawArc(double x1, double y1, double x2, double y2) {
			cout << "    Draw vector arc: ("<<x1<<","<<y1<<") ("<<x2<<","<<y2<<")\n";
		}
};

class DrawRaster : public DrawImpl {
	public: 
		DrawRaster() {name = "raster";}
	public: 
		virtual void drawLine(double x1, double y1, double x2, double y2) {
			cout << "    Draw raster line: ["<<x1<<","<<y1<<"] ["<<x2<<","<<y2<<"]\n";
		}
		virtual void drawArc(double x1, double y1, double x2, double y2) {
			cout << "    Draw raster arc: ("<<x1<<","<<y1<<") ("<<x2<<","<<y2<<")\n";
		}
};

class DrawPlotter : public DrawImpl {
	public: 
		DrawPlotter() {name = "plotter";}
	public: 
		virtual void drawLine(double x1, double y1, double x2, double y2) {
			cout << "    Draw plotter line: ["<<x1<<","<<y1<<"] ["<<x2<<","<<y2<<"]\n";
		}
		virtual void drawArc(double x1, double y1, double x2, double y2) {
			cout << "    Draw plotter arc: ("<<x1<<","<<y1<<") ("<<x2<<","<<y2<<")\n";
		}
};

class Shape {
	public :
		virtual ~Shape() {
			DTOR(" ~Shape\n", Homework);
		}
		virtual void draw(DrawImpl* Impl) = 0;
};

class Rectangle : public Shape {
	private: 
		double x1;
		double y1;
		double x2;
		double y2;
	public: 
		Rectangle(double x1, double y1, double x2, double y2) : x1(x1), y1(y1), x2(x2), y2(y2){}
	public: 
		virtual ~Rectangle() {
			DTOR(" ~Rectangle", Homework);
		}
	public: 
		virtual void draw(DrawImpl* Impl)
		{
			cout << "  Rectangle.draw(x1,y1, x2,y2)<" << Impl->name << ">\n";
			Impl->drawLine(x1,y1, x2,y1);
			Impl->drawLine(x2,y1, x2,y2);
			Impl->drawLine(x2,y2, x1,y2);
			Impl->drawLine(x1,y2, x1,y1);
		}
};

class Circle : public Shape {
	private: 
		double x;
		double y;
		double r;
	public: 
		Circle(double x, double y, double radius) : x(x), y(y), r(radius){}
	public: 
		virtual ~Circle() {
			DTOR(" ~Circle", Homework);
		}
	public: 
		virtual void draw(DrawImpl* Impl)
		{
			cout << "  Circle.draw(x,y, radius)<" << Impl->name << ">\n";
			Impl->drawArc(x,y+r, x+r,y);
			Impl->drawArc(x+r,y, x,y-r);
			Impl->drawArc(x,y-r, x-r,y);
			Impl->drawArc(x-r,y, x,y+r);
		}
};

class Triangle : public Shape {
	private: 
		pair<double,double>	vert1;
		pair<double,double>	vert2;
		pair<double,double>	vert3;
	public: 
		Triangle(pair<double,double> vert1,
				 pair<double,double> vert2,
				 pair<double,double> vert3): vert1(vert1), vert2(vert2), vert3(vert3){}
	public: 
		virtual ~Triangle() {
			DTOR(" ~Triangle", Homework);
		}
	public: 
		virtual void draw(DrawImpl* Impl)
		{
			cout << "  Triangle.draw(vert1, vert2, vert3)<" << Impl->name << ">\n";
			Impl->drawLine(vert1.first,vert1.second, vert2.first,vert2.second);
			Impl->drawLine(vert2.first,vert2.second, vert3.first,vert3.second);
			Impl->drawLine(vert3.first,vert3.second, vert1.first,vert1.second);
		}
};

// Seam point - add another shape.

void demo(int seqNo) {
	cout << seqNo << ") << bridge::solution::legacy::demo() >>\n";
	DrawImpl* platforms[] = { new DrawVector, new DrawRaster, new DrawPlotter};
	Shape*	shapes[] = { new Rectangle(1,1, 2,3),
						 new Circle(4,4, 1.0),
						 new Triangle(make_pair(1.0,1.0),
									  make_pair(2.0,2.0),
									  make_pair(2.0,1.0)) };

	for(size_t i=0; i<COUNT(shapes); i++) {
		for(size_t j=0; j<COUNT(platforms); j++) {
			shapes[i]->draw(platforms[j]);
		}
		cout << endl;
	}

	for(size_t i=0; i<COUNT(shapes); i++)	delete shapes[i];
	for(size_t i=0; i<COUNT(platforms); i++)	delete platforms[i];
	cout << endl;
}

} // solution

} // bridge

#endif /* SOLUTIONS_BRIDGE_H_ */
